import {versions, lifeCycle, access} from "../data/constants.js";

export default {
    getAllHierarchies: (req, res) => {
        let hierarchy = new Map();
        for (let i=1; i<=10; i++) {
            let typeName = 'Type Name - ' + i;
            let components = [];
            for (let j=0; j<5; j++) {
                components.push(new Component(typeName));
            }
            hierarchy.set(typeName, components);
        }
        return res.status(200).json({
            success: true,
            data: Object.fromEntries(hierarchy)
        })
    }

};

class Component {
    constructor(typeName) {
        this.type = typeName ? new Type(typeName) : new Type;
        this.id = Math.floor(Math.random() * 100);
        let random = Math.floor(Math.random() * 5);
        this.lifecycleStage = lifeCycle[random];
        this.schemaNamespace = "www.sampleurl.com";
        this.subscribers = Math.floor(Math.random() * 100);
        this.blueprintVersion = versions[random];
    }
}

class Type {
    constructor(typeName) {
        this.id = Math.floor(Math.random() * 100);
        this.name = typeName ? typeName : 'Type Name'
        let random = Math.floor(Math.random() * 4);
        this.access = access
    }
}