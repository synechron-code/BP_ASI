import {paginate} from "paginate-info";
import {environments, tags, versions, lifeCycle} from "../data/constants.js";

export default {
    getAllBluePrints: (req, res) => {
        let { query: {currentPage, pageSize}} = req;
        !req.query.currentPage ? currentPage = 1 : ''
        !req.query.pageSize ? pageSize = 10 : '';
        let blueprints = [];
        for (let i=1; i<=50; i++) {
            blueprints.push(new Blueprint(i))
        }
        const count = blueprints.length;
        const paginatedData = blueprints;
        const pageInfo = paginate(currentPage, count * currentPage,paginatedData)
        return res.status(200).json({
            success: true,
            data: {
                result: paginatedData,
                meta: pageInfo
            }
        })
    },

    getBlueprint: (req, res) => {
        let id = req.params.id;
        let blueprintVersion = new BlueprintVersion(id);
        id ? blueprintVersion.id = id : '';
        return res.status(501).json({
            success: true,
            data: blueprintVersion
        })
    },

    createNewBlueprint: (req, res) => {
      let id = req.params.id;
      let blueprintVersion = req.body;
      id ? blueprintVersion.id = id : '';
      return res.status(501).json({
          success: true,
          data: blueprintVersion
      })
    },

    updateBlueprint: (req, res) => {
        let id = req.params.id;
        let blueprintVersion = req.body;
        blueprintVersion.id = id;
        Object.entries(req.body).map(([key, value]) => {
            blueprintVersion[key] = value;
        });
        return res.status(501).json({
            success: true,
            data: blueprintVersion
        })
    },

    deleteBlueprint: (req, res) => {
        let id = req.params.id;
        let blueprintVersion = req.body;
        blueprintVersion.id = id;
        Object.entries(req.body).map(([key, value]) => {
            blueprintVersion[key] = value;
        });
        return res.status(200).json({
            success: true,
            data: 'Blueprint deleted successfully'
        })
    }
};

class Blueprint {
    constructor(id) {
        this.id = id;
        this.type = 'Blueprint Type - ' + id;
        this.name = 'Blueprint Name - ' + id;
        this.description = 'Blueprint Description - ' + id;
        let random = Math.floor(Math.random() * 5)
        this.environment = environments[random];
        this.tags = tags;
        this.blueprintVersion = versions;
    }
}

class BlueprintVersion {
    constructor() {
        this.id = Math.floor(Math.random() * 100);
        this.createdDate = new Date();
        this.createdBy = 'System';
        let random = Math.floor(Math.random() * 5);
        this.lifeCycleStage = lifeCycle[random];
        this.tags = tags;
        this.version = versions;
        this.lastModifiedDate = new Date();
        this.blueprintVersionId = Math.random();
        this.nodes = generateChildNodes(0, '')
    }
}

const generateChildNodes = (depth, parentId) => {
    let randomNumber = Math.floor(Math.random() * 3) + 1;
    let childNodesArr = [];
    if (depth < 4) {
        for (let i = 0; i< randomNumber; i++) {
            childNodesArr.push(new Node(depth + 1), parentId)
        }
    }
    return childNodesArr;
}

class Node {
    constructor(depth, parentId) {
        this.id = Math.floor(Math.random() * 100);
        this.parentId = parentId;
        this.title = 'Blueprint Title';
        this.type = 'Blueprint Type';
        this.nodeLevel = depth;
        this.properties = generateProperties(0);
        this.children = generateChildNodes(depth, this.id)
    }
}

const generateProperties = (depth) => {
    let randomNumber = Math.floor(Math.random() * 3) + 1;
    let propertyArr = [];
    if (depth < 4) {
        for (let i = 0; i< randomNumber; i++) {
            propertyArr.push(new PropertyData(depth + 1))
        }
    }
    return propertyArr;
}

class PropertyData {
    constructor(depth) {
        this.id = Math.random();
        this.title = 'Blueprint Title';
        this.type = 'Blueprint Type';
        this.required = new Boolean();
        this.description = 'Blueprint Description';
        this.example = 'Blueprint Example';
        this.pattern = 'regEx';
        this.const = new Boolean();
        this.default = 'Blueprint Default';
        this.properties = generateProperties(depth);
    }
}