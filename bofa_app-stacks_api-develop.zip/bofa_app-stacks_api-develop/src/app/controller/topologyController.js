import {paginate} from "paginate-info";
import {environments, tags, versions, lifeCycle} from "../data/constants.js";

export default {
    getAllTopologies: (req, res) => {
        let { query: {currentPage, pageSize}} = req;
        !req.query.currentPage ? currentPage = 1 : ''
        !req.query.pageSize ? pageSize = 10 : '';
        let topologies = [];
        for (let i=1; i<=50; i++) {
            topologies.push(new Topology(i))
        }
        const count = topologies.length;
        const paginatedData = topologies;
        const pageInfo = paginate(currentPage, count * currentPage,paginatedData)
        return res.status(200).json({
            success: true,
            data: {
                result: paginatedData,
                meta: pageInfo
            }
        })
    },

    getTopology: (req, res) => {
        let id = req.params.id;
        let topologyVersion = new TopologyVersion(id);
        id ? topologyVersion.id = id : '';
        return res.status(501).json({
            success: true,
            data: topologyVersion
        })
    },

    createNewTopology: (req, res) => {
      let id = req.params.id;
      let topologyVersion = req.body;
      id ? topologyVersion.id = id : '';
      return res.status(501).json({
          success: true,
          data: topologyVersion
      })
    },

    updateTopology: (req, res) => {
        let id = req.params.id;
        let topologyVersion = req.body;
        topologyVersion.id = id;
        Object.entries(req.body).map(([key, value]) => {
            topologyVersion[key] = value;
        });
        return res.status(501).json({
            success: true,
            data: topologyVersion
        })
    },

    deleteTopology: (req, res) => {
        let id = req.params.id;
        let topologyVersion = req.body;
        topologyVersion.id = id;
        Object.entries(req.body).map(([key, value]) => {
            topologyVersion[key] = value;
        });
        return res.status(200).json({
            success: true,
            data: 'Topology deleted successfully'
        })
    }
};

class Topology {
    constructor(id) {
        this.id = id;
        this.type = 'Topology Type - ' + id;
        this.name = 'Topology Name - ' + id;
        this.description = 'Topology Description - ' + id;
        let random = Math.floor(Math.random() * 5)
        this.environment = environments[random];
        this.tags = tags;
        this.topologyVersion = versions;
    }
}

class TopologyVersion {
    constructor() {
        this.id = Math.floor(Math.random() * 100);
        this.createdDate = new Date();
        this.createdBy = 'System';
        let random = Math.floor(Math.random() * 5);
        this.lifeCycleStage = lifeCycle[random];
        this.tags = tags;
        this.version = versions;
        this.lastModifiedDate = new Date();
        this.blueprintId = Math.floor(Math.random() * 100)
        this.blueprintVersion = versions;
        this.nodes = generateChildNodes(0, '')
    }
}

const generateChildNodes = (depth, parentId) => {
    let randomNumber = Math.floor(Math.random() * 3) + 1;
    let childNodesArr = [];
    if (depth < 4) {
        for (let i = 0; i< randomNumber; i++) {
            childNodesArr.push(new Node(depth + 1), parentId)
        }
    }
    return childNodesArr;
}

class Node {
    constructor(depth, parentId) {
        this.id = Math.floor(Math.random() * 100);
        this.parentId = parentId;
        this.title = 'Topology Title';
        this.type = 'Topology Type';
        this.nodeLevel = depth;
        this.properties = generateProperties(0);
        this.children = generateChildNodes(depth, this.id)
    }
}

const generateProperties = (depth) => {
    let randomNumber = Math.floor(Math.random() * 3) + 1;
    let propertyArr = [];
    if (depth < 4) {
        for (let i = 0; i< randomNumber; i++) {
            propertyArr.push(new PropertyData(depth + 1))
        }
    }
    return propertyArr;
}

class PropertyData {
    constructor(depth) {
        this.id = Math.random();
        this.title = 'Topology Title';
        this.type = 'Topology Type';
        this.required = new Boolean();
        this.description = 'Topology Description';
        this.example = 'Topology Example';
        this.pattern = 'regEx';
        this.const = new Boolean();
        this.default = 'Topology Default';
        this.properties = generateProperties(depth);
    }
}