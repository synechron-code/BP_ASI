import {eventTypes, collections} from "../data/constants.js";
import {paginate} from "paginate-info";

export default {
    getEvents: (req, res) => {
        let { query: {currentPage, pageSize}} = req;
        !req.query.currentPage ? currentPage = 1 : ''
        !req.query.pageSize ? pageSize = 10 : '';
        let events = [];
        for (let i=1; i<=50; i++) {
            events.push(new Event(i))
        }
        const count = events.length;
        const paginatedData = events;
        const pageInfo = paginate(currentPage, count * currentPage,paginatedData)
        return res.status(200).json({
            success: true,
            data: {
                result: paginatedData,
                meta: pageInfo
            }
        })
    },

    getEvent: (req, res) => {
        let id = req.params.id;
        let event = new Event(id);
        event.id = id;
        return res.status(200).json({
            success: true,
            data: event
        });
    }

};

class Event {
    constructor(id) {
        this.id = id;
        let random = Math.floor(Math.random() * 5);
        this.eventType = eventTypes[random]
        this.collection = collections[random]
        this.objectId = random;
        this.eventDetails = "Event Details - " + random
        this.dateTime = new Date();
    }
}