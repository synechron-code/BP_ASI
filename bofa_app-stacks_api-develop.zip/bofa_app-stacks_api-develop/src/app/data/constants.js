export const environments = ['dev', 'qa', 'uat', 'stage', 'prod'];
export const tags = [1, 2, 3, 4, 5]
export const versions = [1.1, 2.2, 3.1, 4.2, 5.0]
export const lifeCycle = ['emerging', 'core', 'declining', 'controlled', 'abstracted'];
export const access = ['Control1', 'Control2','Control3', 'Control4']
export const eventTypes = ['Success', 'Failure', 'Error']
export const collections = ['Blueprint', 'Topology']