/*const blueprintRoutes = (app, fs) => {
    // variables
    const dataPath = '../bofa_app_stacks_node_api/src/app/data/blueprints.json';

    // READ
    app.get('/blueprints', (req, res) => {
        fs.readFile(dataPath, 'utf8', (err, data) => {
            if (err) {
                throw err;
            }
            res.send(JSON.parse(data));
        });
    });

};*/

import express from "express";
const router = express.Router();
import  hierarchyController from "../controller/hierarchyController.js";

router.route('/blueprints')
    .get(hierarchyController.getAllHierarchies);

router.route('/topologies')
    .get(hierarchyController.getAllHierarchies)

export default router;