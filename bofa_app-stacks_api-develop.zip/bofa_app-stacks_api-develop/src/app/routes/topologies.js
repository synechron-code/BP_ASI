/*
const topologiesRoutes = (app, fs) => {
    // variables
    const dataPath = '../bofa_app_stacks_node_api/src/app/data/topologies.json';

    // READ
    app.get('/topologies', (req, res) => {
        fs.readFile(dataPath, 'utf8', (err, data) => {
            if (err) {
                throw err;
            }
            res.send(JSON.parse(data));
        });
    });
};

module.exports = topologiesRoutes;*/

import express from "express";
const router = express.Router();
import  topologyController from "../controller/topologyController.js";

router.route('/')
    .get(topologyController.getAllTopologies)
    .post(topologyController.createNewTopology);

router.route('/:id')
    .get(topologyController.getTopology)
    .put(topologyController.updateTopology)
    .patch(topologyController.updateTopology)
    .delete(topologyController.deleteTopology)

export default router;
