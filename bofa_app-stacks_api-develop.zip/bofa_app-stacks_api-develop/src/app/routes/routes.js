/*
const blueprintRoutes = require('./blueprints');
const topologiesRoutes = require('./topologies');

const appRouter = (app, fs) => {
    // we've added in a default route here that handles empty routes
    // at the base API url
    app.get('/', (req, res) => {
        res.send('Get Blueprints Successful');
    });

    // run our user route module here to complete the wire up
    blueprintRoutes(app, fs);
    topologiesRoutes(app, fs);
};

module.exports = appRouter;*/

import express from "express";
import blueprintRoutes from "./blueprints.js";
import topologyRoutes from "./topologies.js";
import hierarchyRoutes from "./hierarchy.js";
import eventRoutes from "./event.js"

const router = express.Router();

router.use('/blueprint', blueprintRoutes);
router.use('/topology', topologyRoutes);
router.use('/hierarchy', hierarchyRoutes);
router.use('/event', eventRoutes);

export default router;
