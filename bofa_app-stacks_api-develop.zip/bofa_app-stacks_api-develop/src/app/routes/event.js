/*const blueprintRoutes = (app, fs) => {
    // variables
    const dataPath = '../bofa_app_stacks_node_api/src/app/data/blueprints.json';

    // READ
    app.get('/blueprints', (req, res) => {
        fs.readFile(dataPath, 'utf8', (err, data) => {
            if (err) {
                throw err;
            }
            res.send(JSON.parse(data));
        });
    });

};*/

import express from "express";
const router = express.Router();
import  eventController from "../controller/eventController.js";

router.route('/')
    .get(eventController.getEvents);

router.route('/:id')
    .get(eventController.getEvent)

export default router;