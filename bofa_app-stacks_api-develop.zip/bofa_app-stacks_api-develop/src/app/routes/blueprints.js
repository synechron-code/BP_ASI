/*const blueprintRoutes = (app, fs) => {
    // variables
    const dataPath = '../bofa_app_stacks_node_api/src/app/data/blueprints.json';

    // READ
    app.get('/blueprints', (req, res) => {
        fs.readFile(dataPath, 'utf8', (err, data) => {
            if (err) {
                throw err;
            }
            res.send(JSON.parse(data));
        });
    });

};*/

import express from "express";
const router = express.Router();
import  blueprintController from "../controller/blueprintController.js";

router.route('/')
    .get(blueprintController.getAllBluePrints)
    .post(blueprintController.createNewBlueprint);

router.route('/:id')
    .get(blueprintController.getBlueprint)
    .put(blueprintController.updateBlueprint)
    .patch(blueprintController.updateBlueprint)
    .delete(blueprintController.deleteBlueprint)

export default router;